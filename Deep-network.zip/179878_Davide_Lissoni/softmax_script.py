import string
import numpy as np
import tensorflow as tf
import random
from sklearn.model_selection import train_test_split

def char_to_int(char):
    return (ord(char)-97)

def one_hot(char):
    num=char_to_int(char)
    for i in range(26):
        if(num==i):
            yield 1
        else:
            yield 0

def make_batch(x,cont,division):
    if(len(x)<=(cont+division)):
        array = np.zeros(shape=(len(x)-cont,x.shape[1]))
        for i in range(len(x)-cont):
            array[i]=x[cont+i]
    else:
        array = np.zeros(shape=(len(x)//division,x.shape[1]))
        for i in range(len(x)//division):
            array[i]=x[cont+i]
    return array
    
def one_hot_array(labels):
    label_one_hot = np.zeros(shape=(len(labels),26))
    i=0
    for label in np.nditer(labels, op_flags=['readwrite']):
        label_one_hot[i]=np.fromiter(one_hot(str(label)), dtype='float32')
        i=i+1
    return label_one_hot

        
data=np.loadtxt("data/train-data.csv", dtype='float32', delimiter=",") 
label=np.loadtxt("data/train-target.csv",dtype='str',delimiter=",")

data_size= data.shape[1]
   

x = tf.placeholder(tf.float32, [None, data_size])
W = tf.Variable(tf.zeros([data_size, 26]))
b = tf.Variable(tf.zeros([26]))
y_hat = tf.nn.softmax(tf.matmul(x, W) + b)
y = tf.placeholder(tf.float32, [None,26])

cross_entropy = tf.reduce_mean(-tf.reduce_sum(y * tf.log(y_hat), reduction_indices=[1]))
train_step = tf.train.GradientDescentOptimizer(0.5).minimize(cross_entropy)
sess = tf.InteractiveSession()
tf.global_variables_initializer().run()

for i in range(1,5):
    rnd=random.randint(1,100)
    train_data, test_data, train_label,test_label = train_test_split(data, label, test_size=0.2, random_state=rnd)
    train_label_size= len(train_label)
    train_label_one_hot=one_hot_array(train_label)
    test_label_one_hot=one_hot_array(test_label)
    for epoch in range(10):
        cont=0
        division=150
        for i in range(division):
            batch_data= make_batch(train_data,cont,division)
            batch_label=make_batch(train_label_one_hot,cont,division)
            cont=cont+train_label_size//division
            sess.run(train_step, feed_dict={x: batch_data, y:batch_label})
        
    correct_prediction = tf.equal(tf.argmax(y_hat, 1), tf.argmax(y, 1))
    accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
    print(sess.run(accuracy, feed_dict={x: test_data, y: test_label_one_hot}))
        
correct_prediction = tf.equal(tf.argmax(y_hat, 1), tf.argmax(y, 1))
accuracy = tf.reduce_mean(tf.cast(correct_prediction, tf.float32))
print(sess.run(accuracy, feed_dict={x: test_data, y: test_label_one_hot}))
import numpy as np
from sklearn.svm import SVC
from sklearn import metrics
from sklearn.model_selection import KFold, cross_val_score

#collect the training data
training_dataset = np.loadtxt('spambase/train-data.csv', delimiter=",")
training_targets= np.loadtxt('spambase/train-targets.csv', delimiter=",")
#collect the test data
test_dataset=np.loadtxt('spambase/test-data.csv', delimiter=",")


#initialize k folds
kf = KFold(n_splits=3, shuffle=True, random_state=42)

#initialize gamma values
gamma_values = [0.001,0.0005,0.0007,0.0003]

#intitalize arrays for scores  
accuracy_scores=[]

#start cycle for every gamma
for gamma in gamma_values:
    
    # Train the classifier with current gamma
    clf = SVC(C=150, kernel='rbf', gamma=gamma)

    # Compute cross-validated  scores
    temp_accuracy = cross_val_score(clf,training_dataset, training_targets, cv=kf.split(training_dataset), scoring='accuracy')
   
    # Compute the mean scores and keep track of it
    accuracy_score = temp_accuracy.mean()
    accuracy_scores.append(accuracy_score)
    

# Get the gamma with highest mean accuracy
best_index = np.array(accuracy_scores).argmax()
best_gamma = gamma_values[best_index] 
#train the classifier using the best gamma
clf = SVC(C=150, kernel='rbf', gamma=best_gamma)
clf.fit(training_dataset,training_targets)
#test the trained classifier
predictions = clf.predict(test_dataset)

#write predictions in a file
outputfile = open('test-labels.txt', 'w')
for prediction in predictions:
  outputfile.write("%s\n" % int(prediction))	
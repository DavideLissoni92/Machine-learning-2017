import numpy as np
from sklearn.svm import SVC
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold, cross_val_score


#collect the training data
training_dataset = np.loadtxt('spambase/train-data.csv', delimiter=",")
training_targets= np.loadtxt('spambase/train-targets.csv', delimiter=",")

#split the training dataset and targets
#80% fror training 20% test
# X-> data y->targets
X_train, X_test, y_train, y_test = train_test_split(training_dataset, training_targets, test_size=0.2, random_state=42)

#initialize k folds
kf = KFold(n_splits=3, shuffle=True, random_state=42)

#initialize gamma values
gamma_values = [0.001,0.0005,0.0007,0.0003]

#intitalize arrays for scores  
accuracy_scores,recall_scores, precision_scores, fmeasure_scores = [],[],[],[]

#start cycle for every gamma
for gamma in gamma_values:
    
    # Train the classifier with current gamma
    clf = SVC(C=150, kernel='rbf', gamma=gamma)

    # Compute cross-validated  scores
    temp_accuracy = cross_val_score(clf,X_train, y_train, cv=kf.split(X_train), scoring='accuracy')
    temp_precision = cross_val_score(clf,X_train, y_train, cv=kf.split(X_train), scoring='precision')
    temp_recall = cross_val_score(clf,X_train,  y_train, cv=kf.split(X_train), scoring='recall')
    temp_fmeasure = cross_val_score(clf,X_train,  y_train, cv=kf.split(X_train), scoring='f1')

    # Compute the mean scores and keep track of it
    accuracy_score = temp_accuracy.mean()
    accuracy_scores.append(accuracy_score)
    precision_score = temp_precision.mean()
    precision_scores.append(precision_score)
    recall_score = temp_recall.mean()
    recall_scores.append(accuracy_score)
    fmeasure_score = temp_fmeasure.mean()
    fmeasure_scores.append(fmeasure_score)

# Get the gamma with highest mean accuracy
best_index = np.array(accuracy_scores).argmax()
best_gamma = gamma_values[best_index] 
#train the classifier using the best gamma
clf = SVC(C=150, kernel='rbf', gamma=best_gamma)
clf.fit(X_train,y_train)
#test the trained classifier
y_pred = clf.predict(X_test)
#calculate scores on the prediction made from the classifier just trained
accuracy = metrics.accuracy_score(y_test, y_pred)
recall = metrics.recall_score(y_test, y_pred)
precision = metrics.precision_score(y_test, y_pred)
fmeasure=metrics.f1_score(y_test, y_pred)

#calculate mean of scores during cross validation
accuracy_mean=sum(accuracy_scores) / float(len(accuracy_scores))
recall_mean=sum(recall_scores) / float(len(recall_scores))
precision_mean=sum(precision_scores) / float(len(precision_scores))
fmeasure_mean=sum(fmeasure_scores) / float(len(fmeasure_scores))

#print out the scores
print("Accuracy mean on cross validation training: ", accuracy_mean)
print("Precision mean on cross validation training: ", precision_mean)
print("Recall mean on cross validation training: ", recall_mean)
print("F1-measure mean on cross validation training: ", fmeasure_mean)

print("Accuracy on best gamma: ",accuracy)
print("Recall on best gamma: ",recall)
print("Precision on best gamma: ",precision)
print("F1 measure on best gamma: ",fmeasure)


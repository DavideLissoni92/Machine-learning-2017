# the np alias is very common
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn import metrics
from sklearn.model_selection import KFold, cross_val_score
from sklearn.model_selection import learning_curve

#collect the training data
training_dataset = np.loadtxt('spambase/train-data.csv', delimiter=",")
training_targets= np.loadtxt('spambase/train-targets.csv', delimiter=",")


#initialize k folds
kf = KFold(n_splits=3, shuffle=True, random_state=42)

#initialize gamma values
gamma_values = [0.001,0.0005,0.0007,0.0003]

#intitalize arrays for scores  
accuracy_scores=[]
#start cycle for every gamma
for gamma in gamma_values:
    
    # Train the classifier with current gamma
    clf = SVC(C=150, kernel='rbf', gamma=gamma)

    # Compute cross-validated  scores
    temp_accuracy = cross_val_score(clf,training_dataset, training_targets, cv=kf.split(training_dataset), scoring='accuracy')
    
    # Compute the mean scores and keep track of it
    accuracy_score = temp_accuracy.mean()
    accuracy_scores.append(accuracy_score)
   
# Get the gamma with highest mean accuracy
best_index = np.array(accuracy_scores).argmax()
best_gamma = gamma_values[best_index] 
#train the classifier using the best gamma
clf = SVC(C=150, kernel='rbf', gamma=best_gamma)
clf.fit(training_dataset,training_targets)

#define plot labels
plt.figure()
plt.title("Accuracy learning curve")
plt.xlabel("Training examples")
plt.ylabel("Score")
plt.grid()

train_sizes, train_scores, test_scores = learning_curve(clf, training_dataset, training_targets, scoring='accuracy')

# Get the mean and std of train and test scores along the varying dataset sizes
train_scores_mean = np.mean(train_scores, axis=1)
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

# Plot the mean and std for the training scores
plt.plot(train_sizes, train_scores_mean, 'o-', color="r", label="Training score")

plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                 train_scores_mean + train_scores_std, alpha=0.1, color="r")

# Plot the mean and std for the cross-validation scores
plt.plot(train_sizes, test_scores_mean, 'o-', color="g", label="Cross-validation score")

plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                 test_scores_mean + test_scores_std, alpha=0.1, color="g")

plt.legend()
plt.show()




plt.figure()
plt.title("Precision learning curve")
plt.xlabel("Training examples")
plt.ylabel("Score")
plt.grid()

train_sizes, train_scores, test_scores = learning_curve(clf, training_dataset, training_targets, scoring='precision')

# Get the mean and std of train and test scores along the varying dataset sizes
train_scores_mean = np.mean(train_scores, axis=1)
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

# Plot the mean and std for the training scores
plt.plot(train_sizes, train_scores_mean, 'o-', color="r", label="Training score")

plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                 train_scores_mean + train_scores_std, alpha=0.1, color="r")

# Plot the mean and std for the cross-validation scores
plt.plot(train_sizes, test_scores_mean, 'o-', color="g", label="Cross-validation score")

plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                 test_scores_mean + test_scores_std, alpha=0.1, color="g")

plt.legend()
plt.show()

plt.figure()
plt.title("Recall learning curve")
plt.xlabel("Training examples")
plt.ylabel("Score")
plt.grid()

train_sizes, train_scores, test_scores = learning_curve(clf, training_dataset, training_targets, scoring='recall')

# Get the mean and std of train and test scores along the varying dataset sizes
train_scores_mean = np.mean(train_scores, axis=1)
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

# Plot the mean and std for the training scores
plt.plot(train_sizes, train_scores_mean, 'o-', color="r", label="Training score")

plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                 train_scores_mean + train_scores_std, alpha=0.1, color="r")

# Plot the mean and std for the cross-validation scores
plt.plot(train_sizes, test_scores_mean, 'o-', color="g", label="Cross-validation score")

plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                 test_scores_mean + test_scores_std, alpha=0.1, color="g")

plt.legend()
plt.show()

plt.figure()
plt.title("F1 measure learning curve")
plt.xlabel("Training examples")
plt.ylabel("Score")
plt.grid()

train_sizes, train_scores, test_scores = learning_curve(clf, training_dataset, training_targets, scoring='f1')

# Get the mean and std of train and test scores along the varying dataset sizes
train_scores_mean = np.mean(train_scores, axis=1)
train_scores_std = np.std(train_scores, axis=1)
test_scores_mean = np.mean(test_scores, axis=1)
test_scores_std = np.std(test_scores, axis=1)

# Plot the mean and std for the training scores
plt.plot(train_sizes, train_scores_mean, 'o-', color="r", label="Training score")

plt.fill_between(train_sizes, train_scores_mean - train_scores_std,
                 train_scores_mean + train_scores_std, alpha=0.1, color="r")

# Plot the mean and std for the cross-validation scores
plt.plot(train_sizes, test_scores_mean, 'o-', color="g", label="Cross-validation score")

plt.fill_between(train_sizes, test_scores_mean - test_scores_std,
                 test_scores_mean + test_scores_std, alpha=0.1, color="g")

plt.legend()
plt.show()








